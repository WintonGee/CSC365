DROP TABLE IF EXISTS flights;
DROP TABLE IF EXISTS airports;
DROP TABLE IF EXISTS airlines;


CREATE TABLE airlines (
  Id int PRIMARY KEY,
  Airline varchar(100),
  Abbreviation varchar(100) UNIQUE,
  Country varchar(100)
);



CREATE TABLE airports (
  City varchar(100),
  AirportCode char(3) UNIQUE,
  AirportName varchar(100),
  Country varchar(100),
  CountryAbbrev varchar(100)
);




CREATE TABLE flights (
  Airline int,
  FlightNo int,
  AirportName char(3),
  SourceAirport varchar(100),
  DestAirport varchar(100) NOT NULL,
  FOREIGN KEY (AirportName) REFERENCES airports (AirportCode),
  FOREIGN KEY (SourceAirport) REFERENCES airports (AirportCode),
  FOREIGN KEY (DestAirport) REFERENCES airports (AirportCode),
  FOREIGN KEY (Airline) REFERENCES airlines (Id),
  UNIQUE(Airline, FlightNo)
);

