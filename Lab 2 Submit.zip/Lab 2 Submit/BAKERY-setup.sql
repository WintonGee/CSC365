DROP TABLE IF EXISTS items;
DROP TABLE IF EXISTS receipts;
DROP TABLE IF EXISTS goods;
DROP TABLE IF EXISTS customers;


CREATE TABLE customers (
  CId int PRIMARY KEY,
  LastName varchar(100),
  FirstName varchar(100)
);



CREATE TABLE goods (
  GId varchar(100) PRIMARY KEY,
  Flavor varchar(100),
  Food varchar(100),
  Price float,
  UNIQUE(Flavor,Food)
);



CREATE TABLE receipts (
  RNumber int PRIMARY KEY,
  SaleDate Date,
  Customer int,
  FOREIGN KEY (Customer) REFERENCES customers (CId)
);



CREATE TABLE items (
  Receipt int NOT NULL,
  Ordinal int NOT NULL,
  Item varchar(100) NOT NULL,
  UNIQUE(Receipt, Ordinal),
  FOREIGN KEY (Receipt) REFERENCES receipts (RNumber),
  FOREIGN KEY (Item) REFERENCES goods (GId)
);

