DROP TABLE IF EXISTS Albums;
DROP TABLE IF EXISTS Band;
DROP TABLE IF EXISTS Instruments;
DROP TABLE IF EXISTS Performance;
DROP TABLE IF EXISTS Songs;
DROP TABLE IF EXISTS Tracklists;
DROP TABLE IF EXISTS Vocals;

CREATE TABLE Albums (
  AId int PRIMARY KEY,
  Title varchar(100),
  Year int,
  Label varchar(100),
  Type varchar(100)
);




CREATE TABLE Band (
  Id int PRIMARY KEY,
  Firstname varchar(100),
  Lastname varchar(100)
);




CREATE TABLE Instruments (
  SongId int,
  BandmateId int,
  Instrument varchar(100),
  UNIQUE(SongId,BandmateId,Instrument)
);




CREATE TABLE Performance (
  SongId int,
  Bandmate int,
  StagePosition varchar(100),
  UNIQUE(SongId,Bandmate)
);




CREATE TABLE Songs (
  SongId int PRIMARY KEY,
  Title varchar(100)
);




CREATE TABLE Tracklists (
  AlbumId int,
  Position varchar(100),
  SongId int
);




CREATE TABLE Vocals (
  SongId int,
  Bandmate varchar(100),
  Type varchar(100)
);

