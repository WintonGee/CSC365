DROP TABLE IF EXISTS tickets;
DROP TABLE IF EXISTS survivals;
DROP TABLE IF EXISTS passengers;

CREATE TABLE passengers (
  PassengerId int PRIMARY KEY,
  LastName varchar(100),
  FirstName varchar(100),
  Age int
);



CREATE TABLE survivals (
  Passenger int NOT NULL,
  Survived int,
  FOREIGN KEY (Passenger) REFERENCES passengers (PassengerId)
);



CREATE TABLE tickets (
  Passenger int NOT NULL,
  PClass int,
  Cabin varchar(100),
  Fare float,
  FOREIGN KEY (Passenger) REFERENCES passengers (PassengerId)
);

